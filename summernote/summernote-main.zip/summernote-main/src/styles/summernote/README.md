Common styles
=============

This directory contains files commonly used in multiple styles.

 - `common.scss`: basic scss for Summernote 
 - `elements.scss`: toolkit for styling
 - `font.scss`: Summernote font which contains svg icons
   - Automatically built from `yarn prebuild` command.
